<div class="our_product romana_client_area romana_section_padding product">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="romana_section_title text-center">
                    <h2>Our <span>Products</span> </h2>
                    <p>We have a large lists of products.</p>
                </div>
            </div>
            <!-- column End -->
        </div>
        <!-- row End -->
        <div class="row ">
            <div class="col-xs-12">
                <div class="romana_client_crsl">




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href="#"><img src="{{url('images/switch.jpg')}}" alt=""><br>


                                <div class="romana_client_title">
                                    <h3><a href="#">Switch</a></h3>
                                </div>
                            </a>
                        </div><br>
                        <div class="romana_single_client_text">
                            <p> We provide Switch at a unbeatable price. We have a vast range of Switche where</p>

                            <div class="read-more"> <a href="{{url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')}}">Order Now</a> </div>
                        </div>
                    </div>




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href="#"><img src="{{url('images/router.jpg')}}" alt=""><br>

                                <div class="romana_client_title">
                                    <h3><a href="#">Router</a></h3>
                                </div>
                            </a>
                        </div><br>
                        <div class="romana_single_client_text">
                            <p> We provide Router at a unbeatable price. We have a vast range of Router where</p>

                            <div class="read-more"> <a href="{{url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')}}">Order Now</a> </div>
                        </div>
                    </div>





                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href="#"><img src="{{url('images/RadioStation.jpg')}}" alt=""><br>

                                <div class="romana_client_title">
                                    <h3><a href="#">Radio Station</a></h3>
                                </div>
                            </a>
                        </div><br>
                        <div class="romana_single_client_text">
                            <p> We have a specialized team for the installation of radio station. </p>

                            <div class="read-more"> <a href="{{url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')}}">Order Now</a> </div>
                        </div>
                    </div>





                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href="#"><img src="{{url('images/ipcamera.png')}}" alt="">
                                <br>

                                <div class="romana_client_title">
                                    <h3><a href="#">IP Camera</a></h3>
                                </div>
                            </a>
                        </div>
                        <div class="romana_single_client_text">
                            <p> We provide IP camera products at a unbeatable price. We have a vast range of</p>

                            <div class="read-more"> <a href="{{url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')}}">Order Now</a> </div>
                        </div>
                    </div>




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href="#">
                                <img src="{{url('images/cc camera.jpg')}}" alt="">
                                <br>
                                <div class="romana_client_title">
                                    <h3><a href="#">CC Camera</a></h3>
                                </div>
                            </a>
                        </div>
                        <div class="romana_single_client_text">
                            <p> We provide cc tv camera products at a unbeatable price. We have a vast range</p>

                            <div class="read-more"> <a href="{{url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')}}">Order Now</a> </div>
                        </div>
                    </div>





                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href="#"><img src="{{url('images/UTPcable.jpg')}}" alt="">

                                <br>
                                <div class="romana_client_title">
                                    <h3><a href="#">UTP Cable</a></h3>
                                </div>
                            </a>
                        </div>
                        <div class="romana_single_client_text">
                            <p> We provide UTP Cable at a unbeatable price. We have a vast range of UTP Cable where
                            </p>

                            <div class="read-more"> <a href="{{url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')}}">Order Now</a> </div>
                        </div>
                    </div>
                    <!-- romana_single_client_text End -->
                </div>
            </div>
            <!-- column End -->
        </div>
        <!-- row End -->
    </div>
    <!-- container End -->
</div>
