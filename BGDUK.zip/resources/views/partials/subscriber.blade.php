<div class="romana_people_trust_area romana_section_padding">
    <div class="container">
        <div class="romana_section_title text-center">
            <h2>Our <span>Partners</span> </h2>
            <p>All are Satisfied Partners.</p>
        </div>
        <div class="row ">
            <div class="col-xs-12">
                <div class="partner_crsl">





                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href=""><img src="{{url('images/partner1.jpg')}}" alt=""></a>
                        </div>
                    </div>




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href=""><img src="{{url('images/partner2.jpg')}}" alt=""></a>
                        </div>
                    </div>




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href=""><img src="{{url('images/partner3.jpg')}}" alt=""></a>

                        </div>
                    </div>




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href=""><img src="{{url('images/partner4.jpg')}}" alt=""></a>

                        </div>
                    </div>




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href=""><img src="{{url('images/partner5.jpg')}}" alt=""></a>

                        </div>
                    </div>




                    <div class="romana_single_client_text_img">
                        <div class="romana_client_img">
                            <a href=""><img src="{{url('images/partner6.jpg')}}" alt=""></a>

                        </div>
                    </div>


                </div>
            </div>

        </div>

    </div>

</div>
