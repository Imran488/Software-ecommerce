<div class="romana_people_trust_area romana_section_padding">
    <div class="container">
        <div class="romana_section_title text-center">
            <h2>Our <span>Services</span> </h2>
            <p>We Offer a wide range of services.</p>
        </div>
        <div class="row ">
            <div class="col-xs-12">
                <div class="partner_crsl">

                    <div class="romana_single_service"><br>
                        <a class="service-icon" href="#"><img src="<?php echo e(url('images/webhosting.png')); ?>" alt="">

                        </a>
                        <a href="#">
                            <h3>WEB HOSTING</h3>

                        </a>
                        <p>BGD Technologies (UK) Limited make registration of web hosting fast,secure,affordable and secure manner.<br>If you are looking to transfer hosting to shared provider.Get in Touch</p><br>

                        <div class="read-more"><a href="<?php echo e(route('read.web.hosting')); ?>">Take Services</a> </div>
                    </div>







                    <div class="romana_single_service">
                        <a class="service-icon" href="#"><img src="<?php echo e(url('images/webdevelopment.png')); ?>" alt="">

                        </a>

                        <a href="#">
                            <h3>DOMAIN REGISTRATION</h3>

                        </a>
                        <p>We provide UK .uk or and the all the popular domain registration services. Our server uptime
                            99.99% compared to others. We ensure high server uptime with superb support and you can get help.</p>
                        <div class="read-more"> <a href="<?php echo e(url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')); ?>">Take Services</a></div>
                    </div>





                    <div class="romana_single_service">
                        <a class="service-icon" href="#"><img src="<?php echo e(url('images/webdevelopment.png')); ?>" alt="">

                        </a>

                        <a href="#">
                            <h3>WEB DEVELOPMENT</h3>

                        </a>
                        <p>BGD Technologies (UK) Limited expertise in web development. We do outsourcing web design and
                            provide hosting services.We developcompany website ,ecommerce solution,Business etc.</p>
                        <div class="read-more"> <a href="<?php echo e(route('read.web.development')); ?>">Take Services</a> </div>
                    </div>




                    <div class="romana_single_service">
                        <a class="service-icon" href="#"><img src="<?php echo e(url('images/manageservices.png')); ?>" alt="">

                        </a>

                        <a href="#">
                            <h3>Digital Marketting</h3>

                        </a>
                        <p>A generic term for connecting devices to each other in order to transfer data back and forth.
                            It often refers to network connections its embraces bridges,switches ,routers .
                        </p>
                        <div class="read-more"> <a href="<?php echo e(route('read.digital.marketting')); ?>">Take Services</a> </div>

                    </div>





                    <div class="romana_single_service">
                        <a class="service-icon" href="#"><img src="<?php echo e(url('images/webdevelopment.png')); ?>" alt="">

                        </a>

                        <a href="#">
                            <h3>WEB DEVELOPMENT</h3>

                        </a>
                        <p>BGD Technologies (UK) Limited expertise in web development. We do outsourcing web design and
                            provide hosting services.We developcompany website ,ecommerce solution,Business etc.</p>
                        <div class="read-more"> <a href="<?php echo e(route('read.web.development')); ?>">Take Services</a> </div>
                    </div>



                </div>
            </div>

        </div>

    </div>

</div>






<?php /**PATH C:\xampp\htdocs\BGDUK\resources\views/partials/service.blade.php ENDPATH**/ ?>