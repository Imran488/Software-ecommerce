<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<center>
    <h1>At A Glance</h1>
    <p>BGD Technology (UK) Limited will help you grow your business in any case. We have 100+ services that can change
        your business standard well.
    </p>
</center>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BGDUK\resources\views/pages/ataglance.blade.php ENDPATH**/ ?>