<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="romana_contact_area">
    <div class="container">
        <div class="row">
            <div class="col-md-11">
                <div class="romana_contact_text romana_section_padding_top">
                    <center>
                        <h2 style=color:Green;><u><b>You can Contact with us Always</b></u></h2>
                    </center>
                </div>
            </div>

        </div>
        <!-- row End -->
        <div class="romana_contact_form romana_section_padding_bottom">
            <div class="row">
                <div class="col-md-4 col-sm-5">
                    <div class="romana_contact_form_left">
                        <div class="romana_single_contact">
                            <h3>Support</h3>
                            <ul>
                                <li><a href="#"><strong><i class="fas fa-phone"></i> Phone :</strong> +447441445018</a>
                                </li>
                                <li><a href="#"> <strong><i class="fas fa-phone"></i> Landline :</strong> +447441445018
                                    </a></li>
                                <li><a href="mailto:info@bgdonline.net"> <strong><i class="far fa-envelope"></i> Email
                                            :</strong> info@bgdtech.uk</a></li>

                            </ul>
                        </div>
                        <div class="romana_single_contact">
                            <h3>Address</h3>
                            <ul>
                                <li><a href="#"><strong><i class="fas fa-map-marked-alt"></i> Address :</strong> 71-75,
                                        Shelton Street,<br> Covent Garden, London, WC2H 9JQ, <br>UNITED KINGDOM
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-sm-7">
                    <div class="contact_form_right">

                        <!--  [contact-form-7 id="129" title="Contact form 1"] -->
                        <div class="service-heading animate" data-anim-type="zoomIn" data-anim-delay="500">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.90772232704!2d-0.12573508479936144!3d51.51490891797599!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487604ccaaa0b0b7%3A0xbe144a0754857ae1!2s71-75%20Shelton%20St%2C%20London%20WC2H%209JQ%2C%20UK!5e0!3m2!1sen!2sbd!4v1643717450338!5m2!1sen!2sbd"width="800" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- container End -->

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BGDUK\resources\views/pages/contactus.blade.php ENDPATH**/ ?>