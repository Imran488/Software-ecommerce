<footer class="romana_footer_area">
    <div id="scrollTop">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M13 7.828V20h-2V7.828l-5.364 5.364-1.414-1.414L12 4l7.778 7.778-1.414 1.414L13 7.828z"
                fill="rgba(247,244,244,1)" /></svg>
    </div>
    <div class="romana_footer_top">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="widget footer_left_text footer_menu">
                        <div class="footer_logo">
                            <a href="#"><img src="<?php echo e(url('images/logo.png')); ?>" style="width: 150px;height: 100px; "
                                    alt="logo"></a>
                        </div>
                        <p>BGD Technologies (UK) Limited main slogan is “Making Changes”. We work together to make a
                            positive change. We started our journey back in 2009 as a private limited company. Since
                            then we make a lot of initiatives. We gather a vast experience as an IT related services and
                            products provider.</p>
                    </div>
                </div>
                <!-- column End -->
                <div class="col-sm-3">
                    <div class="widget footer_menu footer_padding_left">
                        <h2 style="color:#2dd967">Contact Us</h2>
                        <ul>
                            <li><a href="#"><i class="fas fa-phone"></i>  Phone : +447441445018 </a></li>
                            <li><a href="#"><i class="fas fa-phone"></i>  Landline :  +447441445018 </a></li>
                            <li><a href="mailto:info@bgdonline.com"><i class="far fa-envelope"></i>  Email : info@bgdtech.uk</a></li>
                            <li> <a href="#"><i class="fas fa-map-marked-alt"></i>  Address :71-75, Shelton Street,<br> Covent Garden, London,<br> WC2H 9JQ,UNITED KINGDOM</a>

                            </li>

                        </ul>
                    </div>
                </div>
                <!-- column End -->
                <div class="col-sm-2">
                    <div class="widget footer_menu widget_right_text">
                        <h2 style="color:#2dd967">Our Services</h2>
                        <ul>
                            <li><a href="<?php echo e(url('https://bgdonline.net/whmcs/cart.php?a=add&domain=register')); ?>">Domain Registration</a></li>
                            <li><a href="<?php echo e(route('read.web.hosting')); ?>">Web Hosting</a></li>
                            <li><a href="<?php echo e(route('read.web.development')); ?>">Web Developing</a></li>
                            <li><a href="<?php echo e(route('read.digital.marketting')); ?>">Digital Marketting</a></li>
                        </ul>
                    </div>
                </div>


                <div class="col-sm-2">
                    <div class="widget footer_menu footer_left10">
                        <h2 style="color:#2dd967">Resources</h2>
                        <ul>
                            <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                            <li><a href="<?php echo e(route('refundpolicy')); ?>">Refund Policy</a></li>
                            <li><a href="<?php echo e(route('termsandcondition')); ?>">Terms and Conditions</a></li>
                            <li><a href="<?php echo e(route('privacy.policy')); ?>">Privacy & Policy</a></li>
                            <li><a href="<?php echo e(route('cookies.policy')); ?>">Cookies policy</a></li>
                            <li><a href="<?php echo e(route('license.agreement')); ?>">License Agreement</a></li>
                        </ul>
                    </div>
                </div>

                <!-- column End -->

                <div class="col-sm-2">
                    <div class="widget footer_menu footer_left10">
                        <h2 style="color:#2dd967">Link</h2>
                        <ul>
                            <li ><a href="<?php echo e(route("home")); ?>">Home</a></li>
                            <li><a href="<?php echo e(('aboutus')); ?>">About Us</a></li>
                            
                            <li><a href="<?php echo e(route('contactus')); ?>"> Support</a></li>
                            <li><a href="<?php echo e(route('copyright')); ?>"> Copyright information</a></li>
                        </ul>
                    </div>
                </div>
                <!-- column End -->
            </div>
        </div>
    </div>
    <!-- footer_top End -->
    <div class="romana_footer_bottom">
        <div class="container">
            <div class="romana_footer_bottom_content text-center">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="copyright_romana">
                            <p><span>&copy;</span>Copyright 2022@BGDTechnologies(UK)Limited®.All Rights Reserved
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="romana_header_top_right romana_footer_social_icon">
                            <ul>
                                <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24">
                                            <path fill="none" d="M0 0h24v24H0z" />
                                            <path
                                                d="M8.49 19.191c.024-.336.072-.671.144-1.001.063-.295.254-1.13.534-2.34l.007-.03.387-1.668c.079-.34.14-.604.181-.692a3.46 3.46 0 0 1-.284-1.423c0-1.337.756-2.373 1.736-2.373.36-.006.704.15.942.426.238.275.348.644.302.996 0 .453-.085.798-.453 2.035-.071.238-.12.404-.166.571-.051.188-.095.358-.132.522-.096.386-.008.797.237 1.106a1.2 1.2 0 0 0 1.006.456c1.492 0 2.6-1.985 2.6-4.548 0-1.97-1.29-3.274-3.432-3.274A3.878 3.878 0 0 0 9.2 9.1a4.13 4.13 0 0 0-1.195 2.961 2.553 2.553 0 0 0 .512 1.644c.181.14.25.383.175.59-.041.168-.14.552-.176.68a.41.41 0 0 1-.216.297.388.388 0 0 1-.355.002c-1.16-.479-1.796-1.778-1.796-3.44 0-2.985 2.491-5.584 6.192-5.584 3.135 0 5.481 2.329 5.481 5.14 0 3.532-1.932 6.104-4.69 6.104a2.508 2.508 0 0 1-2.046-.959l-.043.177-.207.852-.002.007c-.146.6-.248 1.017-.288 1.174-.106.355-.24.703-.4 1.04a8 8 0 1 0-1.656-.593zM12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"
                                                fill="rgba(247,241,241,1)" /></svg></a></li>
                                <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24">
                                            <path fill="none" d="M0 0h24v24H0z" />
                                            <path
                                                d="M3.064 7.51A9.996 9.996 0 0 1 12 2c2.695 0 4.959.99 6.69 2.605l-2.867 2.868C14.786 6.482 13.468 5.977 12 5.977c-2.605 0-4.81 1.76-5.595 4.123-.2.6-.314 1.24-.314 1.9 0 .66.114 1.3.314 1.9.786 2.364 2.99 4.123 5.595 4.123 1.345 0 2.49-.355 3.386-.955a4.6 4.6 0 0 0 1.996-3.018H12v-3.868h9.418c.118.654.182 1.336.182 2.045 0 3.046-1.09 5.61-2.982 7.35C16.964 21.105 14.7 22 12 22A9.996 9.996 0 0 1 2 12c0-1.614.386-3.14 1.064-4.49z"
                                                fill="rgba(247,244,244,1)" /></svg></a></li>
                                <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24">
                                            <path fill="none" d="M0 0h24v24H0z" />
                                            <path
                                                d="M15.3 5.55a2.9 2.9 0 0 0-2.9 2.847l-.028 1.575a.6.6 0 0 1-.68.583l-1.561-.212c-2.054-.28-4.022-1.226-5.91-2.799-.598 3.31.57 5.603 3.383 7.372l1.747 1.098a.6.6 0 0 1 .034.993L7.793 18.17c.947.059 1.846.017 2.592-.131 4.718-.942 7.855-4.492 7.855-10.348 0-.478-1.012-2.141-2.94-2.141zm-4.9 2.81a4.9 4.9 0 0 1 8.385-3.355c.711-.005 1.316.175 2.669-.645-.335 1.64-.5 2.352-1.214 3.331 0 7.642-4.697 11.358-9.463 12.309-3.268.652-8.02-.419-9.382-1.841.694-.054 3.514-.357 5.144-1.55C5.16 15.7-.329 12.47 3.278 3.786c1.693 1.977 3.41 3.323 5.15 4.037 1.158.475 1.442.465 1.973.538z"
                                                fill="rgba(247,244,244,1)" /></svg></a></li>
                                <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24">
                                            <path fill="none" d="M0 0h24v24H0z" />
                                            <path
                                                d="M13.004 18.423a2 2 0 0 1 1.237.207 3.25 3.25 0 0 0 4.389-4.389 2 2 0 0 1-.207-1.237 6.5 6.5 0 0 0-7.427-7.427 2 2 0 0 1-1.237-.207A3.25 3.25 0 0 0 5.37 9.76a2 2 0 0 1 .207 1.237 6.5 6.5 0 0 0 7.427 7.427zM12 20.5a8.5 8.5 0 0 1-8.4-9.81 5.25 5.25 0 0 1 7.09-7.09 8.5 8.5 0 0 1 9.71 9.71 5.25 5.25 0 0 1-7.09 7.09c-.427.066-.865.1-1.31.1zm.053-3.5C9.25 17 8 15.62 8 14.586c0-.532.39-.902.928-.902 1.2 0 .887 1.725 3.125 1.725 1.143 0 1.776-.624 1.776-1.261 0-.384-.188-.808-.943-.996l-2.49-.623c-2.006-.504-2.37-1.592-2.37-2.612C8.026 7.797 10.018 7 11.89 7c1.72 0 3.756.956 3.756 2.228 0 .545-.48.863-1.012.863-1.023 0-.835-1.418-2.9-1.418-1.023 0-1.596.462-1.596 1.126 0 .663.803.876 1.502 1.035l1.836.409C15.49 11.695 16 12.876 16 13.989 16 15.713 14.675 17 12.015 17h.038z"
                                                fill="rgba(254,247,247,1)" /></svg></a></li>
                                <li><a href="https://www.facebook.com/bgdonlineltd/"><svg
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24"
                                            height="24">
                                            <path fill="none" d="M0 0h24v24H0z" />
                                            <path
                                                d="M13 9h4.5l-.5 2h-4v9h-2v-9H7V9h4V7.128c0-1.783.186-2.43.534-3.082a3.635 3.635 0 0 1 1.512-1.512C13.698 2.186 14.345 2 16.128 2c.522 0 .98.05 1.372.15V4h-1.372c-1.324 0-1.727.078-2.138.298-.304.162-.53.388-.692.692-.22.411-.298.814-.298 2.138V9z"
                                                fill="rgba(252,250,250,1)" /></svg></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- column End -->
                </div>
                <!-- row End -->
            </div>
            <!-- container End -->
        </div>
    </div>
    <!-- footer_bottom End -->
</footer>
<?php /**PATH C:\xampp\htdocs\BGDUK\resources\views/partials/footer.blade.php ENDPATH**/ ?>