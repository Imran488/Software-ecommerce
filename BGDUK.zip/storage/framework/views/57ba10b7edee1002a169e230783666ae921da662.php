<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<center>
    <h1><b><u>SignUp Here</u></b></h1><br>
    <form action="<?php echo e(route('user.signup')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputEmail1">Name</label>
            <input type="name" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"placeholder="Enter Your Name"required>
        </div>


        <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"placeholder="Enter email"required>
            <strong id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</strong>
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password"required>
            <strong id="passwordHelp" class="form-text text-muted">Password Should be Strong.</strong>
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Mobile Number</label>
            <input type="number" name="mobile" class="form-control" id="exampleInputPassword1" placeholder="Enter Your Contact Number"required>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-danger">Cancel</a>
    </form>
    <div style="height: 100px;"></div>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BGDUK\resources\views/pages/signup.blade.php ENDPATH**/ ?>