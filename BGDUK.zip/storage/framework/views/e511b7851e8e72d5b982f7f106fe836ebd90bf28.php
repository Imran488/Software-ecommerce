<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<center>
    <h1><b><u>Please Login</u></b></h1><br>
    <form action="<?php echo e(route('user.login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                placeholder="Enter email">
            <strong id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</strong>
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter Password">
            <strong id="passwordHelp" class="form-text text-muted">If You Have Didnt Account SignUp First</strong>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
        <a href="<?php echo e(route('signup')); ?>" class="btn btn-primary">SignUp</a>
    </form>
    <div style="height: 100px;"></div>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BGDUK\resources\views/pages/login.blade.php ENDPATH**/ ?>